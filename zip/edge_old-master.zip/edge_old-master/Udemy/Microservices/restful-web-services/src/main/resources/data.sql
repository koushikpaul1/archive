
insert into user values(1001,sysdate(),'A');
insert into user values(1002,sysdate(),'B');
insert into user values(1003,sysdate(),'C');
insert into user values(1004,sysdate(),'D');
insert into user values(1005,sysdate(),'E');
insert into user values(1006,sysdate(),'F');



insert into post values(11001,'post 1',1001);
insert into post values(11002,'post 2',1001);
insert into post values(11003,'post 3',1001);
insert into post values(11004,'post 4',1001);
insert into post values(11005,'post 5',1001);