case class ReflectWeatherRecord(year: Int, temperature: Int, stationId: String) {
  def this() = this(0, 0, null)
}