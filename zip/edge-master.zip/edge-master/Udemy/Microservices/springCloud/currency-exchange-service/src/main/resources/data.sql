insert into exchange_value( id,currency_from,currency_to,conversion_multiple,port) values (10001,'USD','INR',60,0);
insert into exchange_value( id,currency_from,currency_to,conversion_multiple,port) values (10002,'EURO','INR',70,0);
insert into exchange_value( id,currency_from,currency_to,conversion_multiple,port) values (10003,'POUND','INR',100,0);
insert into exchange_value( id,currency_from,currency_to, conversion_multiple,port) values (10004,'AUS','INR',20,0);