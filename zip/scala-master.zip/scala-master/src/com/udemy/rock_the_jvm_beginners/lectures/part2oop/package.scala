package com.udemy.rock_the_jvm_beginners.lectures

/**
  * Created by Daniel.
  */
package object part2oop {

  def sayHello: Unit = println("Hello, Scala")
  val SPEED_OF_LIGHT = 299792458
}
