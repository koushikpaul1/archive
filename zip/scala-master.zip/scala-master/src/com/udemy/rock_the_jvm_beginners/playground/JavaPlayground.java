package com.udemy.rock_the_jvm_beginners.playground;

/**
 * Created by Daniel.
 */
public class JavaPlayground {


    public static void main(String args[]) {
        System.out.println(Person.N_EYES);
    }
}

class Person {
    public static final int N_EYES = 2;
}

