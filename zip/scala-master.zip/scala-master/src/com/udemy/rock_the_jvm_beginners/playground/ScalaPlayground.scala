package com.udemy.rock_the_jvm_beginners.playground

/**
  * Created by Daniel.
  */
object ScalaPlayground extends App {
  println("Hello, Scala!")
}
