package com.udemy.rock_the_jvm_beginners.playground

/**
  * Created by Daniel.
  */
class Cinderella {

}
