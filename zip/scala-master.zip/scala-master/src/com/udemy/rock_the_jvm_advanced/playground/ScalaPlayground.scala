package com.udemy.rock_the_jvm_advanced.playground

/**
  * Created by Daniel.
  */
object ScalaPlayground extends App {
  println("Hello, Scala")
}
