package com.udemy.rock_the_jvm_advanced.playground;

/**
 * Created by Daniel.
 */
public class JavaPlayground {
    public static void main(String[] args) {
        System.out.println("Hello, Java");
    }
}
