
 interface MyInterface1 {

}
