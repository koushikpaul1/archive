package groupingComparator;

public class Just {

}
