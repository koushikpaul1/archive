
public class Just1 {
	
	public static  void main (String arg []){
		
		Just1 kk=new Just1();
		kk.test(1,10);
		
	}
	
	
	void test (int a,int b){
		for (int x=a;x<b;x++){
			
			
		}
		
		
		
	}

}
